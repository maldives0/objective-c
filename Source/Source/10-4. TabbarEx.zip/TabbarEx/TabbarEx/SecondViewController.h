//
//  SecondViewController.h
//  TabbarEx
//
//  Created by ChoiJinYoung on 3/5/16.
//  Copyright © 2016 appstamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *resultLabel;

- (IBAction)secondAction:(id)sender;
@end
