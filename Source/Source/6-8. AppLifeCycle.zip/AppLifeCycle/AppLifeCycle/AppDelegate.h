//
//  AppDelegate.h
//  AppLifeCycle
//
//  Created by ChoiJinYoung on 3/3/16.
//  Copyright © 2016 appstamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

